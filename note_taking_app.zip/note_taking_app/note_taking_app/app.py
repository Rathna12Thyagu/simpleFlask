from flask import Flask, render_template, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace 'your_secret_key_here' with an actual secret key

# Function to get user notes from session
def get_user_notes():
    if 'notes' not in session:
        session['notes'] = []
    return session['notes']

@app.route('/', methods=["GET", "POST"])
def index():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == "POST":
        note = request.form.get('note')
        notes = get_user_notes()
        notes.append(note)
        session['notes'] = notes

    return render_template("home.html", notes=get_user_notes())

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get('username')
        session['username'] = username
        return redirect(url_for('index'))

    return render_template("login.html")

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('notes', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
